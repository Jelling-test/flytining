# 🎨 BRUGERFLOWS OG UI SPECIFIKATIONER

**Opdateret:** 16. december 2025

---

## 👥 BRUGERTYPER

| Type | Adgang | Login |
|------|--------|-------|
| **Gæst** | Gæsteportal | Magic link (email) |
| **Staff** | Reception funktioner | Email/password |
| **Admin** | Fuld kontrol | Email/password |

---

## 🔄 FLOW 1: Gæst Booking → Portal

```
┌─────────────────────────────────────────────────────────────┐
│ 1. BOOKING OPRETTET I SIRVOY                                │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. SIRVOY WEBHOOK → Supabase                                │
│    - Opretter kunde i regular_customers                     │
│    - Tilføjer nummerplader til approved_plates              │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. VELKOMST EMAIL SENDES                                    │
│    - Trigger: scheduled-emails (dagligt kl. 09:00)          │
│    - Eller: manuelt fra admin                               │
│    - Indhold: Magic link til gæsteportal                    │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. GÆST KLIKKER MAGIC LINK                                  │
│    URL: jelling.vercel.app/m/{booking_id}/{token}           │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 5. VALIDATE-MAGIC-LINK                                      │
│    - Tjekker token                                          │
│    - Tjekker booking periode                                │
│    - Returnerer gæstedata                                   │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 6. GÆSTEPORTAL DASHBOARD                                    │
│    - Velkomstbesked                                         │
│    - Navigation til alle funktioner                         │
│    - Sprogvalg (DA/EN/DE/NL)                                │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔄 FLOW 2: Køb Strømpakke

```
┌─────────────────────────────────────────────────────────────┐
│ 1. GÆST ÅBNER "STRØM" SIDEN                                 │
│    - Ser nuværende pakke (hvis aktiv)                       │
│    - Ser forbrug                                            │
│    - Knap: "Køb strøm"                                      │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. VÆLG PAKKE                                               │
│    - 25 kWh - 75 kr                                         │
│    - 50 kWh - 150 kr                                        │
│    - 100 kWh - 300 kr                                       │
│    - Eller: Indtast custom beløb                            │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. CREATE-CHECKOUT                                          │
│    - Opretter Stripe Checkout Session                       │
│    - Metadata: booking_id, amount, type                     │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. STRIPE CHECKOUT PAGE                                     │
│    - Gæst indtaster kortoplysninger                         │
│    - Betaler                                                │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 5. STRIPE-WEBHOOK                                           │
│    - Modtager checkout.session.completed                    │
│    - Opretter pakke i plugin_data                           │
│    - Sender ON kommando til måler                           │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 6. GÆST REDIRECTES TIL STRØM SIDEN                          │
│    - Ser ny aktiv pakke                                     │
│    - Måler er tændt                                         │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔄 FLOW 3: Bom Åbning (Automatisk)

```
┌─────────────────────────────────────────────────────────────┐
│ 1. BIL KØRER MOD BOM                                        │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. AXIS KAMERA DETEKTERER NUMMERPLADE                       │
│    - Sender webhook med plate_text, confidence              │
│    - Inkluderer billede                                     │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. AXIS-ANPR-WEBHOOK                                        │
│    - Gemmer i plate_detections                              │
│    - Tjekker approved_plates                                │
└─────────────────────────────────────────────────────────────┘
                          │
            ┌─────────────┴─────────────┐
            ▼                           ▼
    ┌───────────────┐           ┌───────────────┐
    │ IKKE GODKENDT │           │ GODKENDT      │
    │               │           │               │
    │ Log og ignorer│           │ Tjek:         │
    └───────────────┘           │ - Tid (07-23) │
                                │ - Checked in  │
                                │ - Rate limit  │
                                └───────────────┘
                                        │
                          ┌─────────────┴─────────────┐
                          ▼                           ▼
                  ┌───────────────┐           ┌───────────────┐
                  │ BETINGELSER   │           │ BETINGELSER   │
                  │ IKKE OPFYLDT  │           │ OPFYLDT       │
                  │               │           │               │
                  │ Log årsag     │           │ ÅBN BOM       │
                  └───────────────┘           │ ON→700ms→OFF  │
                                              │ Log i gate_   │
                                              │ openings      │
                                              └───────────────┘
```

---

## 📱 UI SPECIFIKATIONER

### Gæsteportal Dashboard

```
┌─────────────────────────────────────────────────────────────┐
│ HEADER                                                       │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ 🏕️ Jelling Camping              [DA] [EN] [DE]          │ │
│ │                                                          │ │
│ │ Velkommen, Peter Hansen                                  │ │
│ │ Booking: #12345 | Plads: F44                             │ │
│ └─────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│ NAVIGATION CARDS (2x3 grid på desktop, 1 kolonne mobil)     │
│                                                              │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐             │
│ │ ⚡          │ │ 📅          │ │ 🥐          │             │
│ │ STRØM       │ │ AKTIVITETER │ │ BAGERI      │             │
│ │             │ │             │ │             │             │
│ │ 35.5 kWh    │ │ 3 events    │ │ Bestil til  │             │
│ │ tilbage     │ │ denne uge   │ │ i morgen    │             │
│ └─────────────┘ └─────────────┘ └─────────────┘             │
│                                                              │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐             │
│ │ 🍽️          │ │ 🏊          │ │ ℹ️          │             │
│ │ CAFÉ        │ │ SVØMMEHAL   │ │ PRAKTISK    │             │
│ │             │ │             │ │ INFO        │             │
│ │ Aftensmad   │ │ Åbent       │ │ WiFi, check │             │
│ │ tilbud      │ │ 08-20       │ │ out, m.m.   │             │
│ └─────────────┘ └─────────────┘ └─────────────┘             │
└─────────────────────────────────────────────────────────────┘
```

### Strøm Side

```
┌─────────────────────────────────────────────────────────────┐
│ ← Tilbage                                         ⚡ Strøm   │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ DIN STRØMPAKKE                                          │ │
│ │                                                          │ │
│ │ ████████████░░░░░░░░░░░░░░░░░░░░░░░░░  35%              │ │
│ │                                                          │ │
│ │ Tilbage:     35.5 kWh                                    │ │
│ │ Brugt:       14.5 kWh                                    │ │
│ │ Total:       50.0 kWh                                    │ │
│ │                                                          │ │
│ │ ⚠️ Din pakke er ved at løbe tør!                        │ │
│ │                                                          │ │
│ │ [ KØB MERE STRØM ]                                       │ │
│ └─────────────────────────────────────────────────────────┘ │
│                                                              │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ DIN MÅLER: F44                                          │ │
│ │                                                          │ │
│ │ Status: 🟢 Online                                        │ │
│ │ Strøm:  🟢 TÆNDT                                         │ │
│ │                                                          │ │
│ │ Forbrug nu:  145 W                                       │ │
│ │ Spænding:    231 V                                       │ │
│ │                                                          │ │
│ │ [ SLUK ]                    [ TÆND ]                     │ │
│ └─────────────────────────────────────────────────────────┘ │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Admin Måler Oversigt

```
┌─────────────────────────────────────────────────────────────┐
│ SIDEBAR          │ MÅLERE                                   │
│                  │                                          │
│ 📊 Dashboard     │ ┌─────────────────────────────────────┐  │
│ ⚡ Målere ←      │ │ Søg: [____________] [Filter ▼]     │  │
│ 👥 Kunder        │ └─────────────────────────────────────┘  │
│ 📦 Pakker        │                                          │
│ 🚗 Bom           │ ┌─────────────────────────────────────┐  │
│ 🍽️ Café          │ │ Måler   │ Status │ Kunde  │ Forbrug │  │
│ 📅 Events        │ ├─────────────────────────────────────┤  │
│ 📖 Guide         │ │ F44     │ 🟢 ON  │ #12345 │ 12.5 kWh│  │
│                  │ │ F45     │ 🔴 OFF │ -      │ 0 kWh   │  │
│                  │ │ F46     │ 🟢 ON  │ #12346 │ 8.2 kWh │  │
│                  │ │ F47     │ ⚫ OFF │ -      │ 5.1 kWh │  │
│                  │ │ ...     │        │        │         │  │
│                  │ └─────────────────────────────────────┘  │
│                  │                                          │
│                  │ Viser 1-50 af 360 målere                 │
│                  │ [◀ Forrige] [Næste ▶]                    │
└──────────────────┴──────────────────────────────────────────┘
```

---

## 🎨 DESIGN SYSTEM

### Farver

```css
/* Primary */
--primary: #2563eb;        /* Blue 600 */
--primary-foreground: #ffffff;

/* Success */
--success: #16a34a;        /* Green 600 */

/* Warning */
--warning: #ca8a04;        /* Yellow 600 */

/* Destructive */
--destructive: #dc2626;    /* Red 600 */

/* Background */
--background: #ffffff;
--foreground: #0f172a;

/* Muted */
--muted: #f1f5f9;
--muted-foreground: #64748b;

/* Border */
--border: #e2e8f0;
```

### Typografi

```css
/* Headings */
font-family: 'Inter', sans-serif;

h1: 2.25rem (36px), font-weight: 700
h2: 1.875rem (30px), font-weight: 600
h3: 1.5rem (24px), font-weight: 600
h4: 1.25rem (20px), font-weight: 600

/* Body */
p: 1rem (16px), font-weight: 400
small: 0.875rem (14px)
```

### Komponenter (shadcn/ui)

```tsx
// Button varianter
<Button variant="default">Primary</Button>
<Button variant="secondary">Secondary</Button>
<Button variant="destructive">Destructive</Button>
<Button variant="outline">Outline</Button>
<Button variant="ghost">Ghost</Button>

// Card
<Card>
  <CardHeader>
    <CardTitle>Title</CardTitle>
    <CardDescription>Description</CardDescription>
  </CardHeader>
  <CardContent>Content</CardContent>
  <CardFooter>Footer</CardFooter>
</Card>

// Badge
<Badge variant="default">Default</Badge>
<Badge variant="secondary">Secondary</Badge>
<Badge variant="destructive">Error</Badge>
<Badge variant="outline">Outline</Badge>

// Alert
<Alert variant="default">Info</Alert>
<Alert variant="destructive">Error</Alert>
```

---

## 📱 RESPONSIVE BREAKPOINTS

```css
/* Mobile first */
sm: 640px   /* Landscape phones */
md: 768px   /* Tablets */
lg: 1024px  /* Laptops */
xl: 1280px  /* Desktops */
2xl: 1536px /* Large screens */
```

### Layout Patterns

```tsx
// Dashboard grid
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">

// Sidebar layout
<div className="flex">
  <aside className="hidden md:block w-64">
  <main className="flex-1">
</div>

// Card grid
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
```

---

## ✅ LOVABLE PROMPT EKSEMPLER

**Dashboard:**
```
Create a guest dashboard with 6 navigation cards in a responsive grid.
Each card has an icon, title, and subtitle.
Cards: Power (⚡), Events (📅), Bakery (🥐), Café (🍽️), Pool (🏊), Info (ℹ️)
Use shadcn Card components with hover effects.
Mobile: 1 column, Tablet: 2 columns, Desktop: 3 columns.
```

**Power Page:**
```
Create a power management page with:
1. Package status card showing remaining kWh as progress bar
2. Warning alert when < 20% remaining
3. "Buy more" button that opens package selection
4. Meter status card with ON/OFF toggle buttons
5. Real-time power reading display (W)
Use shadcn Card, Progress, Alert, Button components.
```

**Admin Table:**
```
Create an admin meters table with columns:
- Meter number (text)
- Status (badge: Online/Offline)
- State (badge: ON/OFF)
- Customer (booking ID or "-")
- Energy (number with kWh suffix)
Add search input and filter dropdown.
Use shadcn Table, Input, Badge, DropdownMenu components.
Pagination at bottom.
```
