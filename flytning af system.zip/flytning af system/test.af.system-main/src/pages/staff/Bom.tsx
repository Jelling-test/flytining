// Staff uses the same Bom component as Admin
import AdminBom from "../admin/Bom";

const StaffBom = () => {
  return <AdminBom />;
};

export default StaffBom;
